# Test environment

Owner: Fernando

A target service the agent watches, plus one script per detection scenario. Each script makes something go wrong on purpose so the detection rules in `server/app/detection.py` have something to catch.

## How the pieces connect

```
                         trigger_*.py scripts
                    (make something go wrong on purpose)
                         |                   |
          control port   |                   |  service port
          (slow/down/up) v                   v  (flood /big, wrong /login)
                 +-----------------------------------+
                 |       target_service.py           |
                 |  :9000 service   :9001 control    |--> logs/auth.log
                 +-----------------------------------+    (failed logins)
                                   ^
                                   |  checks every 10 s:
                                   |  up? response time? traffic?
                          +-------------------+
                          |   run_agent.py    |  (Danny's agent, pointed here)
                          +-------------------+
                                   |  POST /report
                                   v
          real server (:8000)  or  mock_server.py (:8765)
          runs detection.py  ->  alerts
```

## Files

| File | What it does |
| --- | --- |
| `target_service.py` | The fake website the agent monitors. Port 9000 is the service; port 9001 is a remote control the triggers use. |
| `run_agent.py` | Runs Danny's agent against the target service without editing `monitoring_agent/config.py`. |
| `mock_server.py` | Stand-in server: accepts `/report`, runs Matthew's `detection.py`, prints alerts and offline agents. Use it until the real server has `/report`. |
| `trigger_traffic_spike.py` | Downloads big files nonstop, which sets off **TRAFFIC_SPIKE**. |
| `trigger_slow_response.py` | Makes the service answer slowly (1500 ms), which sets off **HIGH_LATENCY**. |
| `trigger_service_down.py` | Turns the service port off for 30 s, which sets off **SERVICE_DOWN**. |
| `trigger_failed_logins.py` | Sends wrong passwords from a fake IP, which sets off **BRUTE_FORCE_SSH** (see note below). |
| `trigger_agent_offline.py` | Starts an extra agent, then kills it, which sets off **AGENT_OFFLINE**. |

All the `env/` scripts only use Python's standard library. The agent needs its own packages:

```bash
pip install -r monitoring_agent/requirements.txt
```

## Running it

Open terminals in the `env/` folder.

**Terminal 1, the target service**
```bash
python target_service.py
```

**Terminal 2, a server.** Use the mock server for now:
```bash
python mock_server.py
```
Once the real server has `POST /report`, run it instead (see the main README).

**Terminal 3, the agent**
```bash
python run_agent.py --server http://127.0.0.1:8765     # mock server
python run_agent.py                                    # real server on :8000
```
Add `--interval 5` for faster reports, or `--agent-id agent-test-02` to run a second agent.

**Terminal 4, the triggers, one at a time**
```bash
python trigger_traffic_spike.py
python trigger_slow_response.py
python trigger_service_down.py
python trigger_failed_logins.py
python trigger_agent_offline.py --server http://127.0.0.1:8765
```

## What you should see

| Scenario | Rule in `detection.py` | Default trigger | Alert appears |
| --- | --- | --- | --- |
| Traffic spike | over 1,000,000 bytes/s per interval | 30 s of downloads | next report |
| Slow response | `response_ms` over 1000 | 1500 ms delay for 30 s | next report |
| Service down | 2 failed checks in a row | 30 s outage | 2nd report after it goes down |
| Failed logins | 5 or more from one IP within 60 s | 8 attempts from `10.0.0.66` | only once the agent reads `auth.log` |
| Agent offline | no report for `OFFLINE_THRESHOLD_S` (30 s) | agent killed after 20 s | about 30 s after the kill |

Example output from `mock_server.py`:
```
11:30:36  ** ALERT TRAFFIC_SPIKE (MEDIUM) agent-test-01: High traffic rate detected: ...
11:30:48  ** ALERT HIGH_LATENCY (LOW) agent-test-01: Service 'target' response time is 1502.06ms.
11:32:15  ** ALERT AGENT_OFFLINE: agent-offline-test has not reported for over 30s
```

## Known issues found by this environment

1. **`detection.py` crashes when a service is down (Matthew).** If the service is down, the agent sends `"response_ms": null`, and `svc.get("response_ms", 0) > 1000` raises a `TypeError`. That means SERVICE_DOWN never fires. The one-line fix:
   ```python
   if (svc.get("response_ms") or 0) > RESPONSE_TIME_THRESHOLD_MS:
   ```
   `mock_server.py` prints `!! detection.py crashed` until this is fixed.
2. **The agent doesn't collect failed logins yet (Danny).** It always sends `"failed_logins": []`. `target_service.py` writes each failed login to `env/logs/auth.log`, one JSON object per line:
   ```json
   {"timestamp": "2026-11-10T18:31:26+00:00", "source_ip": "10.0.0.66", "username": "admin"}
   ```
   A collector that reads new lines from this file and puts them in `failed_logins` will make BRUTE_FORCE_SSH work.
3. **On Windows, the traffic spike may not show up.** Traffic sent to `127.0.0.1` may not be counted in Windows' network totals. Run the agent and target on Linux, macOS, or WSL, or run the target on another machine and pass `--target-host`.
